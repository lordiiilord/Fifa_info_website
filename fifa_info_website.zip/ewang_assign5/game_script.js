
/*
	Author: Jesse Ewang
    Due Date:  4/12/2018
	Assignment 5
	
    Filename: game_script.css
	*/
	
function awards(){
	document.write("<ul>");
	document.write("<li>E3 2017 Best Sport Game Award</li>");
	document.write("<li>2017 Global Games Awards - Best Sport game - 1st place</li>");
	document.write("<li>2017 Global Games Awards - Best Multiplayer game - 4th place</li>");
	document.write("</ul>");
}

function profile(x){
	alert("The character's name is " + x);
}

function order(e){
	var name = document.getElementById("custName");
	var email = document.getElementById("custEmail");
	var phone = document.getElementById("custPhone");
	var age = document.getElementById("custAge");
    if(name.value=="" || email.value== "" || phone.value== "" || age.value == ""){
		alert("Please fill in all fields");
		e.preventDefault();
	}
	else {
		alert("Thank you!");
	}
}
var names = ["Manchester United", "Real Madrid", "Barcelona", "Bayern Munich", "Juventus", "Paris Saint-Germain", "Chelsea"];
var defense = [82, 84, 83, 85, 86, 84, 83];
var midfield = [84, 86, 85, 86, 83, 84, 85];
var attack = [85, 84, 91, 88, 90, 87, 84];

function info(){
	document.write("<table>");
	document.write("<caption>*Not all stats are updated to current.</caption>");
	document.write("<tr>")
	document.write("<th>Name</th>");
	document.write("<th>Defense</th>");
	document.write("<th>Midfield</th>");
	document.write("<th>Attack</th>");
	document.write("</tr>");
	for (var i = 0; i < defense.length; i++) {
		document.write("<tr>")
		document.write("<td>" + names[i] + "</td>");
		document.write("<td>" + defense[i] + "</td>");
		document.write("<td>" + midfield[i] + "</td>");
		document.write("<td>" + attack[i] + "</td>");
		document.write("</tr>")
	}
	document.write("</table>");
}